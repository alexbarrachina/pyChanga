from musica import *

set_piano()

def key_listener(key, code):
    print(key)
    if len(key) == 1: 
        piano(ord(key)-24, 1.0, 0.06, block=False)


register_keyboard_listener(key_listener)

while True:
    wait(0.06)
    
    
    2321234345