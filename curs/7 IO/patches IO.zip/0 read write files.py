f = open('./texte.txt')
print("Això és tot el fitxer:\n" , f.read())
f.close()

print("\n")

# line by line
f = open('./texte.txt')
print("el fitxer, línia per línia:\n")
print("lin1: ", f.readline())
print("lin2: ", f.readline())
print("lin3: ", f.readline())
print("lin4: ", f.readline())
f.close()

print("\n")

# a list of lines
f = open('./texte.txt')
lines = f.readlines()
print(lines)
f.close()

f = open('nou_texte.txt','w')
f.write('Això és un test d\'escriptura \n')

valor = ('LA4', 440)
s = str(valor)
f.write(s)
f.close()