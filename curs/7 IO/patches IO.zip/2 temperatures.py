f = open("temperatures.csv")
big_str = f.read()

line_list = big_str.split("\n")
print(line_list)

for line in line_list:
    value_list = line.split(",")
    city = value_list[0]
    date = value_list[1]
    temp = float(value_list[2])
    if temp < 48:
        print('\n' + city + " cold on " + date)
     