f = open("mary.txt")
big_str = f.read()
line_list = big_str.split("\n")

first_line = line_list[0]
last_line = line_list[3]
first_line_word_list = first_line.split(" ")
last_line_word_list = last_line.split(" ")

print(big_str + '\n')
print(line_list)

print('\n')
print(first_line_word_list[3])
print(last_line_word_list[-1])
