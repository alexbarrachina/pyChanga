import pygame

pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

while True:
    for event in pygame.event.get():
        pass

'''
run = True
while run:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
          run = False

pygame.quit()
'''
