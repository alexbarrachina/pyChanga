import pygame

pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

PINK = (255, 0, 255)
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

rect_1 = pygame.Rect(200, 100, 150, 100)

print(rect_1)

while True:
    for event in pygame.event.get():
        pass

    pygame.draw.rect(screen, PINK, rect_1)
    #pygame.draw.circl(screen, PINK, pos, 20)
    pygame.display.update()
    


