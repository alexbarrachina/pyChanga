import pygame

pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

PINK = (255, 0, 255)
BLACK = (0,0,0)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

image = pygame.image.load("ufo.png")
imagePos = (300, 200)

while True:

    for event in pygame.event.get():
        pass

    screen.fill(BLACK)   
    screen.blit(image, imagePos)
    pygame.display.update()
    


