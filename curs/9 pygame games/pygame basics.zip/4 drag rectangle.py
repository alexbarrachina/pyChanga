import pygame

pygame.init()

SCREEN_WIDTH = 600
SCREEN_HEIGHT = 400

PINK = (255, 0, 255)
BLACK = (0,0,0)

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

rect_1 = pygame.Rect(200, 100, 150, 100)
print(rect_1)

while True:

    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONUP:
          rect_1.center = pygame.mouse.get_pos()

    screen.fill(BLACK)   
    pygame.draw.rect(screen, PINK, rect_1)
    pygame.display.update()


# ok, but the rectangle should move while the mouse is dragging.



